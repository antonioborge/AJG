
function showTable(ano) {
    var tabelas = document.querySelectorAll('table');
    for (var i = 0; i < tabelas.length; i++) {
      tabelas[i].style.display = 'none';
    }
    var tabelaAtual = document.getElementById(ano);
    if (tabelaAtual) {
      tabelaAtual.style.display = 'table';
    }
  }
