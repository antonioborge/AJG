function aplicarHorarios() {
  
  const cursoSelecionado = document.getElementById("curso").value;
  const anoSelecionado = document.getElementById("ano").value;

  
  const urlsPDF = {
    "Multimédia": {
      "1ºano": "../../../public/assets/images/Multimédia_1ano.pdf",
      "2ºano": "../../../public/assets/images/Multimédia_2ano.pdf",
      "3ºano": "../../../public/assets/images/Multimédia 3ºano.pdf",

    },
    "Design de jogos digitais": {
      "1ºano": "../../../public/assets/images/Design de jogos digitais_1ano.pdf",
      "2ºano": "../../../public/assets/images/Design de jogos digitais_2ano.pdf",
      "3ºano": "../../../public/assets/images/Design de jogos digitais_3ano.pdf",

    },
    "Solicitadoria": {
      "1ºano": "../../../public/assets/images/Solicitadoria 1ºano.pdf",
      "2ºano": "../../../public/assets/images/Solicitadoria 2ºano.pdf",
      "3ºano": "../../../public/assets/images/Solicitadoria 3ºano.pdf",
    },
    "Jornalismo": {
      "1ºano": "../../../public/assets/images/Jornalismo_1ano.pdf",
      "2ºano": "../../../public/assets/images/Jornalismo 2_ano.pdf",
      "3ºano": "../../../public/assets/images/Jornalismo 3_ano.pdf"




    },
    "Turismo": {
      "1ºano": "../../../public/assets/images/Turismo 1ºano.pdf",
      "2ºano": "../../../public/assets/images/Turismo 2ºano.pdf",
      "3ºano": "../../../public/assets/images/Turismo 3ºano.pdf"  
    },
    "Informática": {
      "1ºano": "../../../public/assets/images/Gestão e Administração Pública 1ºano.pdf",
      "2ºano": "../../../public/assets/images/Gestão e Administração Pública 2ºano.pdf",
      "3ºano": "../../../public/assets/images/Gestão e Administração Pública 3ºano.pdf"
    },
    "Gestão e Administração Pública": {

      "1ºano": "../../../public/assets/images/Informática e comunicações 1ºano.pdf",
      "2ºano": "../../../public/assets/images/Informática e comunicações 2ºano.pdf",
      "3ºano": "../../../public/assets/images/Informática e comunicações 3ºano.pdf"
      
    },
    "Marketing": {
      "1ºano": "../../../public/assets/images/Marketing_1ano.pdf",
      "2ºano": "../../../public/assets/images/Marketing 2ºano.pdf",
      "3ºano": "../../../public/assets/images/Marketing 3ºano.pdf"  

      
    },
    
  };

 
  const horariosContainer = document.getElementById("horarios-container");
  horariosContainer.innerHTML = "";

  const urlPDF = urlsPDF[cursoSelecionado]?.[anoSelecionado];
  if (urlPDF) {
    
    const iframe = document.createElement("iframe");
    iframe.src = urlPDF;
    iframe.width = "100%";
    iframe.height = "500px";

    
    horariosContainer.appendChild(iframe);
  } else {
    console.error("Curso ou ano não encontrado:", cursoSelecionado, anoSelecionado);
  }
}
