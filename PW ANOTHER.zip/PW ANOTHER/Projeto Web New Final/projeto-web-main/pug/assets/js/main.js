console.log("teste");

document.addEventListener('DOMContentLoaded', function() {
	// Navbar :
  function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('top-[5%]');
  }

  function toggleDropdown(button) {
      const dropdown = button.nextElementSibling;
      dropdown.classList.toggle('hidden');
      const icon = button.querySelector('ion-icon');
      icon.name = dropdown.classList.contains('hidden') ? 'chevron-down-outline' : 'chevron-up-outline';
  }

  // Adicione os eventos de clique para os botões
  document.querySelectorAll('.nav-links button').forEach(function(button) {
      button.addEventListener('click', function() {
          toggleDropdown(this);
      });
  });
    
	// Slider 
	    var glide02 = new Glide('.glide-02', {
	      type: 'slider',
	      focusAt: 'center',
	      perView: 1,
	      autoplay: 3500,
	      animationDuration: 700,
	      gap: 0,
	      classes: {
	          activeNav: '[&>*]:bg-slate-700',
	      },

	  });

	  glide02.mount();

	// btn scroll back to top page 

	// Exibir ou ocultar o botão com base no rolar da página
    window.onscroll = function () {
      const scrollToTopBtn = document.getElementById('scrollToTopBtn');
      const shouldShow = window.scrollY > 20;

      scrollToTopBtn.style.display = shouldShow ? 'block' : 'none';
    };

    // Função para rolar suavemente até o topo
    document.getElementById('scrollToTopBtn').addEventListener('click', function () {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });


});
console.log("passou");

